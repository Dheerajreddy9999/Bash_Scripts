#!/bin/bash

for VAR1 in java .net ptython ruby php
do
  echo "Looping....."
  sleep 1
  echo "###############################################"
  echo "Valueof VAR1 is $VAR1"
  echo "###############################################"
  date
done


