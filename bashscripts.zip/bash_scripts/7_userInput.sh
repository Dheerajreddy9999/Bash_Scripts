#!/bin/bash

echo "enter your skills:"
read SKILL


echo "your $SKILL skill is in high demand in the IT industry."

read -p 'Username:' USR
read -sp 'Password:' pass

echo 

echo "Login Successfull: Welcome USER $USR,"
