#!/bin/bash


echo "Value 0f 0 is"
echo $0

echo "Value 0f 1 is"
echo $1

echo "Value 0f 2 is"
echo $2

echo "Value 0f 3 is"
echo $3

echo "Value 0f 4 is"
echo $4
